//
//  test_astrologfyTests.swift
//  test_astrologfyTests
//
//  Created by Amit kumar on 08/01/26.
//

import Testing

struct test_astrologfyTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
