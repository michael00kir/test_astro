//
//  ContentView.swift
//  Stardust - Spiritual AI Guide
//
//  Created for test_astrologfy on 08/01/26.
//

import SwiftUI

struct ContentView: View {
    @State private var viewModel = StardustViewModel()
    @State private var inputText = ""
    @FocusState private var isInputFocused: Bool
    
    var body: some View {
        ZStack {
            // Mystical gradient background
            cosmicBackground
            
            VStack(spacing: 0) {
                // Header
                headerView
                
                // Main content
                if viewModel.isAvailable {
                    chatInterface
                } else {
                    unavailableView
                }
            }
        }
        .preferredColorScheme(.dark)
    }
    
    // MARK: - Background
    
    private var cosmicBackground: some View {
        LinearGradient(
            colors: [
                Color(red: 0.05, green: 0.02, blue: 0.15),
                Color(red: 0.1, green: 0.05, blue: 0.25),
                Color(red: 0.08, green: 0.03, blue: 0.2)
            ],
            startPoint: .topLeading,
            endPoint: .bottomTrailing
        )
        .ignoresSafeArea()
        .overlay {
            // Subtle star particles
            StarsOverlay()
        }
    }
    
    // MARK: - Header
    
    private var headerView: some View {
        VStack(spacing: 8) {
            HStack(spacing: 12) {
                Image(systemName: "sparkles")
                    .font(.system(size: 28, weight: .light))
                    .foregroundStyle(
                        LinearGradient(
                            colors: [.purple, .pink, .orange],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                    )
                    .symbolEffect(.pulse, options: .repeating)
                
                Text("Stardust")
                    .font(.system(size: 32, weight: .light, design: .serif))
                    .foregroundStyle(
                        LinearGradient(
                            colors: [.white, .purple.opacity(0.8)],
                            startPoint: .leading,
                            endPoint: .trailing
                        )
                    )
            }
            
            Text("Your Spiritual Guide")
                .font(.system(size: 14, weight: .light))
                .foregroundColor(.white.opacity(0.6))
                .tracking(2)
        }
        .padding(.vertical, 20)
        .frame(maxWidth: .infinity)
        .background(.ultraThinMaterial.opacity(0.3))
    }
    
    // MARK: - Chat Interface
    
    private var chatInterface: some View {
        VStack(spacing: 0) {
            // Messages list
            ScrollViewReader { proxy in
                ScrollView {
                    LazyVStack(spacing: 16) {
                        // Welcome message if empty
                        if viewModel.messages.isEmpty && !viewModel.isGenerating {
                            welcomeMessage
                        }
                        
                        // Chat messages
                        ForEach(viewModel.messages) { message in
                            MessageBubble(message: message)
                                .id(message.id)
                        }
                        
                        // Streaming response
                        if viewModel.isGenerating && !viewModel.currentResponse.isEmpty {
                            StreamingBubble(content: viewModel.currentResponse)
                                .id("streaming")
                        }
                        
                        // Loading indicator
                        if viewModel.isGenerating && viewModel.currentResponse.isEmpty {
                            LoadingIndicator()
                                .id("loading")
                        }
                        
                        // Error message
                        if let error = viewModel.errorMessage {
                            ErrorBubble(message: error)
                        }
                    }
                    .padding()
                }
                .onChange(of: viewModel.messages.count) { _, _ in
                    withAnimation {
                        proxy.scrollTo(viewModel.messages.last?.id, anchor: .bottom)
                    }
                }
                .onChange(of: viewModel.currentResponse) { _, _ in
                    withAnimation {
                        proxy.scrollTo("streaming", anchor: .bottom)
                    }
                }
            }
            
            // Input area
            inputArea
        }
    }
    
    // MARK: - Welcome Message
    
    private var welcomeMessage: some View {
        VStack(spacing: 16) {
            Image(systemName: "moon.stars.fill")
                .font(.system(size: 48))
                .foregroundStyle(
                    LinearGradient(
                        colors: [.purple, .blue, .cyan],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                )
                .symbolEffect(.breathe, options: .repeating)
            
            Text("Welcome, Seeker")
                .font(.system(size: 24, weight: .light, design: .serif))
                .foregroundColor(.white)
            
            Text("Ask me about your path, the stars above,\nor any spiritual guidance you seek.")
                .font(.system(size: 15, weight: .light))
                .foregroundColor(.white.opacity(0.7))
                .multilineTextAlignment(.center)
                .lineSpacing(4)
            
            // Suggestion chips
            VStack(spacing: 10) {
                SuggestionChip(text: "What do the stars say about my day?") {
                    sendSuggestion("What do the stars say about my day?")
                }
                SuggestionChip(text: "Guide me in meditation") {
                    sendSuggestion("Guide me in a brief meditation for inner peace")
                }
                SuggestionChip(text: "I need encouragement") {
                    sendSuggestion("I'm feeling down and need some spiritual encouragement")
                }
            }
            .padding(.top, 8)
        }
        .padding(.vertical, 40)
    }
    
    // MARK: - Input Area
    
    private var inputArea: some View {
        HStack(spacing: 12) {
            // Text field with glassmorphism
            TextField("Ask the cosmos...", text: $inputText, axis: .vertical)
                .textFieldStyle(.plain)
                .padding(.horizontal, 16)
                .padding(.vertical, 12)
                .background(
                    RoundedRectangle(cornerRadius: 24)
                        .fill(.ultraThinMaterial)
                        .overlay(
                            RoundedRectangle(cornerRadius: 24)
                                .strokeBorder(
                                    LinearGradient(
                                        colors: [.white.opacity(0.2), .purple.opacity(0.3)],
                                        startPoint: .topLeading,
                                        endPoint: .bottomTrailing
                                    ),
                                    lineWidth: 1
                                )
                        )
                )
                .foregroundColor(.white)
                .focused($isInputFocused)
                .lineLimit(1...5)
                .onSubmit {
                    sendMessage()
                }
            
            // Send button
            Button(action: sendMessage) {
                Image(systemName: "arrow.up.circle.fill")
                    .font(.system(size: 36))
                    .foregroundStyle(
                        LinearGradient(
                            colors: inputText.isEmpty ? [.gray.opacity(0.5), .gray.opacity(0.3)] : [.purple, .pink],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                    )
                    .symbolEffect(.bounce, value: !inputText.isEmpty)
            }
            .disabled(inputText.isEmpty || viewModel.isGenerating)
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 12)
        .background(.ultraThinMaterial.opacity(0.5))
    }
    
    // MARK: - Unavailable View
    
    private var unavailableView: some View {
        VStack(spacing: 24) {
            Spacer()
            
            Image(systemName: "moon.zzz.fill")
                .font(.system(size: 64))
                .foregroundColor(.purple.opacity(0.6))
            
            Text("Stardust is Sleeping")
                .font(.system(size: 24, weight: .light, design: .serif))
                .foregroundColor(.white)
            
            Text("Apple Intelligence is required to awaken\nthe spiritual guidance within.")
                .font(.system(size: 15, weight: .light))
                .foregroundColor(.white.opacity(0.7))
                .multilineTextAlignment(.center)
                .lineSpacing(4)
            
            Text("Enable Apple Intelligence in System Settings")
                .font(.system(size: 13))
                .foregroundColor(.purple.opacity(0.8))
                .padding(.horizontal, 20)
                .padding(.vertical, 10)
                .background(
                    Capsule()
                        .strokeBorder(.purple.opacity(0.4), lineWidth: 1)
                )
            
            Spacer()
        }
        .padding()
    }
    
    // MARK: - Actions
    
    private func sendMessage() {
        let message = inputText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !message.isEmpty else { return }
        
        inputText = ""
        
        Task {
            await viewModel.sendMessage(message)
        }
    }
    
    private func sendSuggestion(_ text: String) {
        Task {
            await viewModel.sendMessage(text)
        }
    }
}

// MARK: - Supporting Views

struct MessageBubble: View {
    let message: StardustMessage
    
    var body: some View {
        HStack {
            if message.isFromUser { Spacer(minLength: 60) }
            
            VStack(alignment: message.isFromUser ? .trailing : .leading, spacing: 4) {
                Text(message.content)
                    .font(.system(size: 15, weight: .regular))
                    .foregroundColor(.white)
                    .padding(.horizontal, 16)
                    .padding(.vertical, 12)
                    .background(
                        RoundedRectangle(cornerRadius: 20)
                            .fill(message.isFromUser ? userBubbleGradient : aiBubbleGradient)
                    )
                    .overlay(
                        RoundedRectangle(cornerRadius: 20)
                            .strokeBorder(
                                AnyShapeStyle(
                                    message.isFromUser
                                    ? AnyShapeStyle(Color.clear)
                                    : AnyShapeStyle(
                                        LinearGradient(
                                            colors: [.purple.opacity(0.4), .blue.opacity(0.2)],
                                            startPoint: .topLeading,
                                            endPoint: .bottomTrailing
                                        )
                                    )
                                ),
                                lineWidth: 1
                            )
                    )
            }
            
            if !message.isFromUser { Spacer(minLength: 60) }
        }
    }
    
    private var userBubbleGradient: LinearGradient {
        LinearGradient(
            colors: [Color.purple.opacity(0.6), Color.blue.opacity(0.4)],
            startPoint: .topLeading,
            endPoint: .bottomTrailing
        )
    }
    
    private var aiBubbleGradient: LinearGradient {
        LinearGradient(
            colors: [Color.white.opacity(0.1), Color.purple.opacity(0.15)],
            startPoint: .topLeading,
            endPoint: .bottomTrailing
        )
    }
}

struct StreamingBubble: View {
    let content: String
    
    var body: some View {
        HStack {
            VStack(alignment: .leading, spacing: 4) {
                HStack(spacing: 6) {
                    Image(systemName: "sparkle")
                        .font(.system(size: 12))
                        .foregroundColor(.purple)
                        .symbolEffect(.variableColor, options: .repeating)
                    
                    Text("Stardust")
                        .font(.system(size: 12, weight: .medium))
                        .foregroundColor(.purple.opacity(0.8))
                }
                
                Text(content)
                    .font(.system(size: 15, weight: .regular))
                    .foregroundColor(.white)
                    .padding(.horizontal, 16)
                    .padding(.vertical, 12)
                    .background(
                        RoundedRectangle(cornerRadius: 20)
                            .fill(
                                LinearGradient(
                                    colors: [Color.white.opacity(0.1), Color.purple.opacity(0.15)],
                                    startPoint: .topLeading,
                                    endPoint: .bottomTrailing
                                )
                            )
                    )
                    .overlay(
                        RoundedRectangle(cornerRadius: 20)
                            .strokeBorder(
                                LinearGradient(
                                    colors: [.purple.opacity(0.4), .blue.opacity(0.2)],
                                    startPoint: .topLeading,
                                    endPoint: .bottomTrailing
                                ),
                                lineWidth: 1
                            )
                    )
            }
            
            Spacer(minLength: 60)
        }
    }
}

struct LoadingIndicator: View {
    var body: some View {
        HStack {
            HStack(spacing: 8) {
                ForEach(0..<3) { index in
                    Circle()
                        .fill(
                            LinearGradient(
                                colors: [.purple, .pink],
                                startPoint: .top,
                                endPoint: .bottom
                            )
                        )
                        .frame(width: 8, height: 8)
                        .scaleEffect(1.0)
                        .animation(
                            .easeInOut(duration: 0.6)
                            .repeatForever()
                            .delay(Double(index) * 0.2),
                            value: UUID()
                        )
                }
            }
            .padding(.horizontal, 20)
            .padding(.vertical, 16)
            .background(
                RoundedRectangle(cornerRadius: 20)
                    .fill(.ultraThinMaterial)
            )
            
            Spacer()
        }
    }
}

struct ErrorBubble: View {
    let message: String
    
    var body: some View {
        HStack {
            Text(message)
                .font(.system(size: 14))
                .foregroundColor(.orange)
                .padding(.horizontal, 16)
                .padding(.vertical, 10)
                .background(
                    RoundedRectangle(cornerRadius: 16)
                        .fill(Color.orange.opacity(0.1))
                        .overlay(
                            RoundedRectangle(cornerRadius: 16)
                                .strokeBorder(.orange.opacity(0.3), lineWidth: 1)
                        )
                )
            
            Spacer()
        }
    }
}

struct SuggestionChip: View {
    let text: String
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            Text(text)
                .font(.system(size: 14, weight: .regular))
                .foregroundColor(.white.opacity(0.9))
                .padding(.horizontal, 16)
                .padding(.vertical, 10)
                .background(
                    Capsule()
                        .fill(.ultraThinMaterial)
                        .overlay(
                            Capsule()
                                .strokeBorder(
                                    LinearGradient(
                                        colors: [.purple.opacity(0.4), .pink.opacity(0.2)],
                                        startPoint: .leading,
                                        endPoint: .trailing
                                    ),
                                    lineWidth: 1
                                )
                        )
                )
        }
        .buttonStyle(.plain)
    }
}

struct StarsOverlay: View {
    var body: some View {
        GeometryReader { geometry in
            ForEach(0..<30, id: \.self) { _ in
                Circle()
                    .fill(.white.opacity(Double.random(in: 0.1...0.4)))
                    .frame(width: CGFloat.random(in: 1...3))
                    .position(
                        x: CGFloat.random(in: 0...geometry.size.width),
                        y: CGFloat.random(in: 0...geometry.size.height)
                    )
            }
        }
    }
}

// MARK: - Preview

#Preview {
    ContentView()
}
