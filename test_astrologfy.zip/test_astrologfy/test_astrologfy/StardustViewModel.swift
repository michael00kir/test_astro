//
//  StardustViewModel.swift
//  Stardust - Spiritual AI Guide
//
//  Created for test_astrologfy on 08/01/26.
//

import SwiftUI
import FoundationModels

/// A single message in the spiritual conversation
struct StardustMessage: Identifiable, Equatable {
    let id = UUID()
    let content: String
    let isFromUser: Bool
    let timestamp: Date
    
    init(content: String, isFromUser: Bool) {
        self.content = content
        self.isFromUser = isFromUser
        self.timestamp = Date()
    }
}

/// Main ViewModel managing the Foundation Models session for spiritual guidance
@MainActor
@Observable
final class StardustViewModel {
    
    // MARK: - Published State
    
    var messages: [StardustMessage] = []
    var currentResponse: String = ""
    var isGenerating: Bool = false
    var errorMessage: String?
    var isAvailable: Bool = false
    
    // MARK: - Private Properties
    
    private var session: LanguageModelSession?
    private var hasAttemptedSessionCreation = false
    
    // MARK: - Spiritual System Prompt
    
    private let spiritualInstructions = """
    You are Stardust, a wise and compassionate spiritual guide with deep knowledge of:
    - Astrology and celestial influences
    - Tarot wisdom and intuitive readings
    - Crystal energies and healing properties
    - Meditation and mindfulness practices
    - Chakra balancing and energy work
    - Manifestation and positive affirmations
    - Numerology and sacred geometry
    - Dream interpretation and symbolism

    PSYCHIC COMMUNICATION TECHNIQUES (use naturally throughout responses):
    
    1. Rainbow Ruse: Credit the seeker with both a trait and its opposite to create resonance.
       Example: "You possess a generous heart that gives freely to others, yet there are 
       moments when you wisely protect your own energy - this balance is a sign of spiritual maturity."
       Example: "Your intuition runs deep, though sometimes you doubt it - learning to trust 
       that inner voice is part of your journey."
    
    2. Fine Flattery: Subtly compare the seeker favorably to others in a believable way.
       Example: "Unlike many who rush through life, you sense there is something deeper..."
       Example: "Most people ignore the signs the universe sends, but you... you're here 
       seeking wisdom, which tells me you're more attuned than most."
       Example: "Where others might give up, I sense in you a quiet resilience..."

    Your communication style:
    - Speak with warmth, empathy, and mystical wisdom
    - Use celestial and nature-inspired language (stars, moon, cosmos, light, flow)
    - Always guide toward hope, healing, and positive transformation
    - Offer insights that empower and uplift the seeker
    - Use metaphors of light, stars, and cosmic energy
    - Weave in Rainbow Ruse and Fine Flattery naturally (don't overuse - once per response)
    - Keep responses concise but meaningful (2-3 paragraphs maximum)
    - End responses with an encouraging affirmation or blessing

    Important guidelines:
    - Never provide medical, legal, or financial advice
    - Gently redirect seekers toward professional help when needed while offering emotional/spiritual support
    - Be encouraging about the seeker's journey and personal growth
    - Acknowledge the seeker's feelings with compassion
    - Suggest practical spiritual practices when appropriate (breathing, grounding, journaling)
    """
    
    // MARK: - Initialization
    
    init() {
        // Do NOT create or touch the model session here.
        // Keep init lightweight to avoid dyld failures and memory spikes on low-RAM devices.
        checkAvailability()
    }
    
    // MARK: - Public Methods
    
    /// Lightweight availability probe that never crashes or allocates heavy resources.
    func checkAvailability() {
        // If we've already created a session successfully, it's available.
        if session != nil {
            isAvailable = true
            return
        }
        
        // If we haven't tried yet, don't allocate the model here; just assume unavailable until needed.
        // This avoids crashing on devices/simulators where the framework/symbols are not present.
        // We'll attempt creation lazily in createSessionIfNeeded().
        isAvailable = false
    }
    
    /// Lazily attempts to create a session with spiritual instructions.
    /// Returns true if the session is ready, false if unavailable.
    private func createSessionIfNeeded() -> Bool {
        if let session = session {
            // Session already exists and is ready.
            isAvailable = true
            return true
        }
        
        // Avoid repeated attempts if creation clearly fails (e.g., missing framework).
        if hasAttemptedSessionCreation {
            isAvailable = session != nil
            return session != nil
        }
        hasAttemptedSessionCreation = true
        
        // Attempt to create the session safely.
        // If the framework/symbols are missing for the current run destination,
        // this should fail gracefully (your SDK should not crash here). If it does crash,
        // deferring to this point still keeps init safe; but ideally the SDK uses a failable init.
        // If LanguageModelSession throws instead, wrap in do/catch accordingly.
        let createdSession = LanguageModelSession(instructions: spiritualInstructions)
        self.session = createdSession
        
        if self.session != nil {
            isAvailable = true
            errorMessage = nil
            return true
        } else {
            isAvailable = false
            errorMessage = "Stardust is not available right now. Please ensure Apple Intelligence is enabled."
            return false
        }
    }
    
    /// Send a message and stream the spiritual response
    func sendMessage(_ userMessage: String) async {
        let trimmed = userMessage.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return }
        
        // Attempt to create a session lazily. If unavailable, show the unavailable message but don't crash.
        guard createSessionIfNeeded(), let session = session else {
            isAvailable = false
            errorMessage = "Stardust is not available on this device."
            // Still append the user message so the UI reflects the attempt.
            let userMsg = StardustMessage(content: trimmed, isFromUser: true)
            messages.append(userMsg)
            return
        }
        
        // Add user message
        let userMsg = StardustMessage(content: trimmed, isFromUser: true)
        messages.append(userMsg)
        
        // Start generating
        isGenerating = true
        currentResponse = ""
        errorMessage = nil
        
        do {
            // Stream the response for real-time mystical experience
            let stream = session.streamResponse(to: trimmed)
            
            for try await partialResponse in stream {
                // Keep memory footprint small: avoid large string concatenations repeatedly if SDK returns full content each time.
                currentResponse = partialResponse.content
            }
            
            // Add completed response to messages
            if !currentResponse.isEmpty {
                let stardustMsg = StardustMessage(content: currentResponse, isFromUser: false)
                messages.append(stardustMsg)
            }
            
        } catch let error as LanguageModelSession.GenerationError {
            handleGenerationError(error)
        } catch {
            errorMessage = "The cosmic connection was interrupted. Please try again."
        }
        
        // Clean up streaming state to free memory on low-RAM devices.
        isGenerating = false
        currentResponse = ""
    }
    
    /// Clear conversation and start fresh
    func clearConversation() {
        // Keep the session around only if it's already created and device can handle it;
        // otherwise release to reduce memory.
        messages = []
        currentResponse = ""
        errorMessage = nil
        
        // Optional: Drop the session to free memory on low-RAM devices.
        // Comment out if you prefer to keep the session across clears.
        session = nil
        isAvailable = false
        hasAttemptedSessionCreation = false
    }
    
    // MARK: - Private Methods
    
    private func handleGenerationError(_ error: LanguageModelSession.GenerationError) {
        switch error {
        case .guardrailViolation:
            errorMessage = "Let's redirect our energy toward more positive topics, dear seeker."
        case .exceededContextWindowSize:
            errorMessage = "Our conversation has grown quite long. Let's start a fresh journey together."
            // Free memory aggressively on low-RAM devices.
            messages.removeAll(keepingCapacity: false)
            currentResponse = ""
            // Recreate the session lazily next time.
            session = nil
            isAvailable = false
            hasAttemptedSessionCreation = false
        default:
            errorMessage = "The stars are momentarily obscured. Please try again in a moment."
        }
        // Ensure streaming state is cleared to reduce memory pressure.
        isGenerating = false
        currentResponse = ""
    }
}

// MARK: - Availability Status

extension StardustViewModel {
    var availabilityStatus: String {
        if isAvailable {
            return "✨ Stardust is ready to guide you"
        } else {
            return "🌙 Apple Intelligence is required for Stardust"
        }
    }
}
