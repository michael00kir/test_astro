//
//  test_astrologfyApp.swift
//  Stardust - Spiritual AI Guide
//
//  Created for test_astrologfy on 08/01/26.
//

import SwiftUI

@main
struct test_astrologfyApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
                .preferredColorScheme(.dark)
        }
        #if os(macOS)
        .windowStyle(.hiddenTitleBar)
        .defaultSize(width: 500, height: 700)
        #endif
    }
}
